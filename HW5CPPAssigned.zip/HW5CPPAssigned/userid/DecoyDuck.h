#ifndef DECOYDUCK_H_
#define DECOYDUCK_H_
#include "Duck.h"

class DecoyDuck : public Duck {
public:
   DecoyDuck( );
   void display( );
};
#endif /* DECOYDUCK_H_ */
