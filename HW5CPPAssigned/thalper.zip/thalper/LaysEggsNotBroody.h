#ifndef LAYSEGGSNOTBROODY_H_
#define LAYSEGGSNOTBROODY_H_
#include "LaysEggs.h"

class LaysEggsNotBroody : public LaysEggs {
public:
   void egg( );
};
#endif /* LAYSEGGSNOTBROODY_H_ */