#ifndef DOESNOTLAYEGGS_H_
#define DOESNOTLAYEGGS_H_
#include "LaysEggs.h"

class DoesNotLayEggs : public LaysEggs {
public:
   void egg( );
};
#endif /* DOESNOTLAYEGGS_H_ */