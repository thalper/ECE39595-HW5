#include <iostream>
#include "FlyNoWay.h"

void FlyNoWay::fly( ) {
   std::cout << "No can fly." << std::endl;
}
