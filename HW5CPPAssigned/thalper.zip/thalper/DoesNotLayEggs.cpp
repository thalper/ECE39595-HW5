#include <iostream>
#include "DoesNotLayEggs.h"

void DoesNotLayEggs::egg( ) {
   std::cout << "Not an egg layer." << std::endl;
}
