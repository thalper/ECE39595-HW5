#ifndef TOYDUCK_H_
#define TOYDUCK_H_
#include "Duck.h"

class ToyDuck : public Duck {
public:
   ToyDuck( );
   void display( );
};
#endif /* TOYDUCK_H_ */