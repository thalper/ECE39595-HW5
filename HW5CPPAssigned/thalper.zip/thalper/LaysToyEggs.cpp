#include <iostream>
#include "LaysToyEggs.h"

void LaysToyEggs::egg( ) {
   std::cout << "Lays toy eggs." << std::endl;
}
