#ifndef FLIESPOORLY_H_
#define FLIESPOORLY_H_
#include "FlyBehavior.h"

class FliesPoorly : public FlyBehavior {
public:
   void fly( );
};
#endif /* FLIESPOORLY_H_ */
