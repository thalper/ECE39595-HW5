#ifndef LAYSEGGS_H_
#define LAYSEGGS_H_

class LaysEggs {
public:
   virtual void egg( ) = 0;
};
#endif /* LAYSEGGS_H_ */